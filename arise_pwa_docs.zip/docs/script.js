
const responseBox = document.getElementById("response");
let speaking = false;
let language = "en-IN";

function speak() {
  const text = "All systems online. Initializing A.R.I.S.E. — your personal assistant. Ready to assist you, Commander.";
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = language;
  utterance.rate = 1.1;

  const voices = window.speechSynthesis.getVoices().filter(v => v.lang === language && v.name.toLowerCase().includes("male"));
  if (voices.length) utterance.voice = voices[0];

  responseBox.textContent = text;
  window.speechSynthesis.speak(utterance);
  speaking = true;
}

function stopSpeaking() {
  window.speechSynthesis.cancel();
  responseBox.textContent = "Speech stopped.";
  speaking = false;
}
